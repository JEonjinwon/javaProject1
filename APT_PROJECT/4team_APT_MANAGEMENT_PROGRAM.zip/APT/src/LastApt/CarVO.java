package LastApt;

public class CarVO {
	private int car_num;
	private String car_owner;
	private String car_type;
	private int car_loc;
	private int addr_num;
	public int getCar_num() {
		return car_num;
	}
	public void setCar_num(int car_num) {
		this.car_num = car_num;
	}
	public String getCar_owner() {
		return car_owner;
	}
	public void setCar_owner(String car_owner) {
		this.car_owner = car_owner;
	}
	public String getCar_type() {
		return car_type;
	}
	public void setCar_type(String car_type) {
		this.car_type = car_type;
	}
	public int getCar_loc() {
		return car_loc;
	}
	public void setCar_loc(int car_loc) {
		this.car_loc = car_loc;
	}
	public int getAddr_num() {
		return addr_num;
	}
	public void setAddr_num(int addr_num) {
		this.addr_num = addr_num;
	}
	
}
