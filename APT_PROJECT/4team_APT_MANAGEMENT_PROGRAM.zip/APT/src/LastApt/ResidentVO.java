package LastApt;

public class ResidentVO {
	private String resident_id;
	private String resident_pass;
	private String resident_name;
	private int resident_code;
	private int addr_num;
	public String getResident_id() {
		return resident_id;
	}
	public String setResident_id(String resident_id) {
		return this.resident_id = resident_id;
	}
	public String getResident_pass() {
		return resident_pass;
	}
	public void setResident_pass(String resident_pass) {
		this.resident_pass = resident_pass;
	}
	public String getResident_name() {
		return resident_name;
	}
	public String setResident_name(String resident_name) {
		return this.resident_name = resident_name;
	}
	public int getResident_code() {
		return resident_code;
	}
	public void setResident_code(int resident_code) {
		this.resident_code = resident_code;
	}
	public int getAddr_num() {
		return addr_num;
	}
	public int setAddr_num(int addr_num) {
		return this.addr_num = addr_num;
	}
	
	

}
