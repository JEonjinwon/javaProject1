package LastApt;

public class GuestVO {
	private int guest_carnum;
	private String guest_name;
	private int addr_num;
	public int getGuest_carnum() {
		return guest_carnum;
	}
	public void setGuest_carnum(int guest_carnum) {
		this.guest_carnum = guest_carnum;
	}
	public String getGuest_name() {
		return guest_name;
	}
	public void setGuest_name(String guest_name) {
		this.guest_name = guest_name;
	}
	public int getAddr_num() {
		return addr_num;
	}
	public void setAddr_num(int addr_num) {
		this.addr_num = addr_num;
	}
	
	
	

}
