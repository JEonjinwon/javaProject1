package LastApt;

public class ExpensesVO {
	private int expenses_electricity;
	private int expenses_water;
	private int expenses_guard;
	private int addr_num;
	public int getExpenses_electricity() {
		return expenses_electricity;
	}
	public void setExpenses_electricity(int expenses_electricity) {
		this.expenses_electricity = expenses_electricity;
	}
	public int getExpenses_water() {
		return expenses_water;
	}
	public void setExpenses_water(int expenses_water) {
		this.expenses_water = expenses_water;
	}
	public int getExpenses_guard() {
		return expenses_guard;
	}
	public void setExpenses_guard(int expenses_guard) {
		this.expenses_guard = expenses_guard;
	}
	public int getAddr_num() {
		return addr_num;
	}
	public void setAddr_num(int addr_num) {
		this.addr_num = addr_num;
	}
	
	
	

}
