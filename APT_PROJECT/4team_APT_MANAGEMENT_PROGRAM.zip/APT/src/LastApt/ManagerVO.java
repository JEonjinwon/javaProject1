package LastApt;

public class ManagerVO {
	
	private String manager_id;
	private String manager_pass;
	private String mamnager_name;
	private String manager_hp;
	private int manager_code;
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public String getManager_pass() {
		return manager_pass;
	}
	public void setManager_pass(String manager_pass) {
		this.manager_pass = manager_pass;
	}
	public String getMamnager_name() {
		return mamnager_name;
	}
	public void setMamnager_name(String mamnager_name) {
		this.mamnager_name = mamnager_name;
	}
	public String getManager_hp() {
		return manager_hp;
	}
	public void setManager_hp(String manager_hp) {
		this.manager_hp = manager_hp;
	}
	public int getManager_code() {
		return manager_code;
	}
	public void setManager_code(int manager_code) {
		this.manager_code = manager_code;
	}
	

	
}
