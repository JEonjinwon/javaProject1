package LastApt;

public class MainClass {

	public static void main(String[] args) {
		System.out.println("┌───────────────────────────────────────────────────────┐");
		System.out.println("│                   	4팀                                                                  │");
		System.out.println("│                   【 APT 관리 프로그램 】                \t        │");
		System.out.println("│                                                       │");
		System.out.println("│                     팀장 : 박찬                                                           │");
		System.out.println("│                     팀원 : 전진원, 김성준                                           │");
		System.out.println("│                                                       │");
		System.out.println("└───────────────────────────────────────────────────────┘");
		ViewClass vc = new ViewClass();
		vc.start();
	}

}
