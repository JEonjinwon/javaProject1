package artproject;

public class CommunityVO {

	private int writer_date;
	private String writer_suggestions;
	private String writer_repl;
	private int writer_num;
	private String resident_id;
	private String manager_id;
	public int getWriter_date() {
		return writer_date;
	}
	public void setWriter_date(int writer_date) {
		this.writer_date = writer_date;
	}
	public String getWriter_suggestions() {
		return writer_suggestions;
	}
	public void setWriter_suggestions(String writer_suggestions) {
		this.writer_suggestions = writer_suggestions;
	}
	public String getWriter_repl() {
		return writer_repl;
	}
	public void setWriter_repl(String writer_repl) {
		this.writer_repl = writer_repl;
	}
	public int getWriter_num() {
		return writer_num;
	}
	public void setWriter_num(int writer_num) {
		this.writer_num = writer_num;
	}
	public String getResident_id() {
		return resident_id;
	}
	public void setResident_id(String resident_id) {
		this.resident_id = resident_id;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	
	
	
}
